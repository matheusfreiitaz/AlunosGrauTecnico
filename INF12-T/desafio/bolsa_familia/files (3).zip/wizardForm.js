let etapaAtual = 1;

export function goStep(step) {
  // 1. Limpa as mensagens de erro antigas
  document.getElementById("nameError").innerText = "";
  document.getElementById("emailError").innerText = "";
  document.getElementById("phoneError").innerText = "";
  document.getElementById("cpfError").innerText = "";
  document.getElementById("dobError").innerText = "";

  // 2. Validações de campos por etapa
  if (step === 2) {
    const nome = document.getElementById("patientName").value;
    const email = document.getElementById("patientEmail").value;
    const phone = document.getElementById("patientPhone").value;
    const cpf = document.getElementById("patientCPF").value;
    const dob = document.getElementById("patientDOB").value;

    let possuiErro = false;

    if (!nome)  { document.getElementById("nameError").innerText  = "Preencha o nome";                possuiErro = true; }
    if (!email) { document.getElementById("emailError").innerText = "Preencha o e-mail";              possuiErro = true; }
    if (!phone) { document.getElementById("phoneError").innerText = "Preencha o telefone";            possuiErro = true; }
    if (!cpf)   { document.getElementById("cpfError").innerText   = "Preencha o CPF";                 possuiErro = true; }
    if (!dob)   { document.getElementById("dobError").innerText   = "Preencha a data de nascimento";  possuiErro = true; }

    if (possuiErro) return;
  }

  if (step === 3) {
    const doctor = document.getElementById("doctor").value;
    let possuiErro = false;
    if (!doctor) {
      document.getElementById("doctorError").innerText = "Selecione um médico";
      possuiErro = true;
    }
    if (possuiErro) return;
  }

  if (step === 4) {
    const consultDate = document.getElementById("consultDate").value;
    const consultTime = document.getElementById("consultTime").value;
    let possuiErro = false;
    if (!consultDate) { document.getElementById("dateError").innerText = "Selecione a data da consulta"; possuiErro = true; }
    if (!consultTime) { document.getElementById("timeError").innerText = "Selecione o horário";          possuiErro = true; }
    if (possuiErro) return;
  }

  // 3. Atualiza a etapa atual e controla a exibição dos passos
  etapaAtual = step;

  document.getElementById("step1").style.display = "none";
  document.getElementById("step2").style.display = "none";
  document.getElementById("step3").style.display = "none";
  document.getElementById("step4").style.display = "none";

  document.getElementById("successMsg").style.display = "none";
  document.getElementById(`step${step}`).style.display = "block";

  // 4. Atualiza os indicadores visuais (bolinhas de progresso)
  const todosPassos = document.querySelectorAll(".steps .step");
  todosPassos.forEach((elementoPasso) => {
    const numeroPasso = parseInt(elementoPasso.getAttribute("data-step"));
    elementoPasso.classList.remove("active", "done");
    if (numeroPasso === etapaAtual) {
      elementoPasso.classList.add("active");
    } else if (numeroPasso < etapaAtual) {
      elementoPasso.classList.add("done");
    }
  });

  // 5. Atualiza o resumo do Passo 4
  const patientName = document.getElementById("patientName").value;
  const patientPhone = document.getElementById("patientPhone").value;
  const patientEmail = document.getElementById("patientEmail").value;
  const patientCPF = document.getElementById("patientCPF").value;
  const doctor = document.getElementById("doctor").value;
  const consultDate = document.getElementById("consultDate").value;
  const consultTime = document.getElementById("consultTime").value;

  const consultTypeInput = document.querySelector('input[name="consultType"]:checked');
  const consultType = consultTypeInput ? consultTypeInput.value : "Presencial";

  const specialtySelecionada = document.querySelector('input[name="specialty"]:checked');
  let specialty = "Não selecionada";
  if (specialtySelecionada) {
    specialty = specialtySelecionada.parentElement.innerText.trim();
  }

  document.getElementById("rev-name").innerText      = patientName;
  document.getElementById("rev-phone").innerText     = patientPhone;
  document.getElementById("rev-email").innerText     = patientEmail;
  document.getElementById("rev-cpf").innerText       = patientCPF;
  document.getElementById("rev-specialty").innerText = specialty;
  document.getElementById("rev-doctor").innerText    = doctor;
  document.getElementById("rev-type").innerText      = consultType;
  document.getElementById("rev-date").innerText      = consultDate;
  document.getElementById("rev-time").innerText      = consultTime;
}

export function finalizarAgendamento() {
  document.getElementById("appointmentForm").style.display = "none";
  document.getElementById("successMsg").style.display = "";
}

export function resetForm() {
  document.getElementById("appointmentForm").reset();
  document.getElementById("successMsg").style.display = "none";
  document.getElementById("appointmentForm").style.display = "block";

  const usuarioLogadoNome = document.querySelector(".user-name").innerText;

  // ATENÇÃO: o e-mail é capturado ANTES do reset; após o reset o campo já está vazio.
  // Por isso salvamos o valor em uma variável antes de chamar goStep(1).
  const usuarioLogadoEmail = document.getElementById("patientEmail").value;

  if (usuarioLogadoNome !== "Paciente") {
    document.getElementById("patientName").value  = usuarioLogadoNome;
    document.getElementById("patientEmail").value = usuarioLogadoEmail;
  }

  goStep(1);
}

export function mascaraTelefone(input) {
  let valor = input.value.replace(/\D/g, "");
  if (valor.length > 11) valor = valor.slice(0, 11);

  if (valor.length > 7) {
    input.value = `(${valor.slice(0, 2)}) ${valor.slice(2, 7)}-${valor.slice(7)}`;
  } else if (valor.length > 2) {
    input.value = `(${valor.slice(0, 2)}) ${valor.slice(2)}`;
  } else if (valor.length > 0) {
    input.value = `(${valor}`;
  } else {
    input.value = "";
  }
}

export function mascaraCPF(input) {
  let valor = input.value.replace(/\D/g, "");
  if (valor.length > 11) valor = valor.slice(0, 11);

  if (valor.length > 9) {
    input.value = `${valor.slice(0, 3)}.${valor.slice(3, 6)}.${valor.slice(6, 9)}-${valor.slice(9)}`;
  } else if (valor.length > 6) {
    input.value = `${valor.slice(0, 3)}.${valor.slice(3, 6)}.${valor.slice(6)}`;
  } else if (valor.length > 3) {
    input.value = `${valor.slice(0, 3)}.${valor.slice(3)}`;
  } else if (valor.length > 0) {
    input.value = `${valor}`;
  } else {
    input.value = "";
  }
}

// Tentando carregar os dados para validação
import usuariosCadastrados from "../data/database.js";

export function toggleAuthMode(isRegistering) {
  const signInForm = document.getElementById("signInForm");
  const signUpForm = document.getElementById("signUpForm");

  document.getElementById("authLoginError").innerText = "";
  document.getElementById("authRegisterError").innerText = "";

  if (isRegistering) {
    signInForm.style.display = "none";
    signUpForm.style.display = "block";
  } else {
    signInForm.style.display = "block";
    signUpForm.style.display = "none";
  }
}

export function fazerLogin() {
  const emailInput = document.getElementById("loginEmail").value.trim();
  const senhaInput = document.getElementById("loginSenha").value;
  const errorElement = document.getElementById("authLoginError");

  errorElement.innerText = "";

  if (!emailInput || !senhaInput) {
    errorElement.innerText = "Por favor, preencha todos os campos.";
    return;
  }

  const usuarioValido = usuariosCadastrados.find(
    u => u.email.toLowerCase() === emailInput.toLowerCase() && u.senha === senhaInput
  );

  if (usuarioValido) {
    document.querySelector(".user-name").innerText = usuarioValido.nome;
    document.getElementById("patientName").value = usuarioValido.nome;
    document.getElementById("patientEmail").value = usuarioValido.email;

    document.getElementById("authScreen").style.display = "none";
    document.getElementById("mainSystem").style.display = "block";
    document.getElementById("sidebar").style.display = "flex";
  } else {
    errorElement.innerText = "E-mail ou senha incorretos.";
  }
}

export function fazerCadastro() {
  const nome = document.getElementById("registerName").value.trim();
  const email = document.getElementById("registerEmail").value.trim();
  const senha = document.getElementById("registerSenha").value;
  const errorElement = document.getElementById("authRegisterError");

  errorElement.innerText = "";

  if (!nome || !email || !senha) {
    errorElement.innerText = "Por favor, preencha todos os campos.";
    return;
  }

  const emailExiste = usuariosCadastrados.some(
    u => u.email.toLowerCase() === email.toLowerCase()
  );
  if (emailExiste) {
    errorElement.innerText = "Este e-mail já está cadastrado.";
    return;
  }

  usuariosCadastrados.push({ nome, email, senha });

  localStorage.setItem("usuariosCadastrados", JSON.stringify(usuariosCadastrados));

  toggleAuthMode(false);
  document.getElementById("authLoginError").style.color = "var(--teal-400)";
  document.getElementById("authLoginError").innerText = "Conta criada! Faça seu login.";

  setTimeout(() => {
    document.getElementById("authLoginError").style.color = "";
  }, 4000);
}

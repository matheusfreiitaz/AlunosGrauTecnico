// 1. CONECTAR COM O HTML, VOU USAR VARIÁVEIS CONSTANTES, OQUE
// SIGNIFICA QUE ELAS NÃO PODEM SER REATRIBUÍDAS (PARTE 1)
const canvas = document.querySelector('canvas')
const ctx = canvas.getContext('2d')
const size = 20

// COMO A COBRA FOI FEITA 001 (ME ACOMPANHE...)
// A cabeça da cobra é o ÚLTIMO elemento do array (index: snake.length - 1)
// SÃO COORDENADAS NA TELA/CANVAS, ENTÃO O X É A POSIÇÃO HORIZONTAL E O Y É A POSIÇÃO VERTICAL
let snake = [
  { x: 200, y: 200 },
  { x: 220, y: 200 },
  { x: 240, y: 200 } // Cabeça inicial, ESSE QUADRADO É DIFERENCIADO, FIQUE VENDO.
]

let direction // Variável para armazenar a direção atual da cobra (inicialmente indefinida)
let loopId    // Variável para armazenar o ID do loop do jogo (usado para
              // controlar o setTimeout) que é o ciclo que redesenha a tela dentro do intervalo definido (50ms nesse caso)
              // o que cria uma ilusão de movimento

// BUG 1 – PONTUAÇÃO
// Essa variável guarda a pontuação atual do jogador
// PISTA: qual valor inicial faz sentido para uma pontuação que ainda não começou?
let score = 10
let highScore = 0

// --- REGRAS DA MAÇÃ ---
// Ficou bonito o título né? kkkkkkkk

// Função para gerar um número aleatório múltiplo de 20 (dentro do grid/canvas) 001
const randomNum = (min, max) => {
  return Math.round((Math.random() * (max - min) + min) / size) * size
  // Gera um número aleatório entre min e max, arredondado para o inteiro mais próximo,
  // garantindo que seja um múltiplo de 20 para se alinhar com o grid do jogo.
}

// BUG 2 – POSIÇÃO ALEATÓRIA
// Função para gerar uma posição aleatória para a maçã, garantindo que
// seja um múltiplo de 20 (tamanho do grid) 002
// PISTA: Observe os argumentos passados para randomNum. O segundo argumento
// deveria ser o limite máximo do canvas menos o tamanho de um bloco.
// O que acontece com a maçã se o limite estiver errado?
const randomPosition = () => {
  return randomNum(0, canvas.width + size)
}

// Posição inicial da maçã
let food = { // Objeto para representar a maçã, com propriedades x, y e color
  x: randomPosition(),
  y: randomPosition(),
  color: "red"
}

// dicas:
// 1. CÊS LEMBRAM DA LÓGICA MATEMÁTICA DOS 20PX?
// 2. E DA LÓGICA DE DIREÇÃO?
// 3. E O PONTINHO VERMELHO? COMO ELE PODE APARECER?

const drawFood = () => {
  ctx.fillStyle = food.color
  ctx.fillRect(food.x, food.y, size, size)
}

// Como a cobra foi feita 002 (tá mais pra cubo né? kkkkkkk)
const drawSnake = () => {
  snake.forEach((position, index) => {
    // Define a cor do corpo
    ctx.fillStyle = "#00aeff"  // Cor da cobra (azul claro)
    ctx.strokeStyle = "black"  // Define a cor da borda para destacar os gomos
    ctx.lineWidth = 2          // Define a largura da borda para destacar os gomos
    ctx.strokeRect(position.x, position.y, size, size)

    // BUG 3 – COR DA CABEÇA
    // Se for o último elemento, que é a cabeça, então muda a cor para Cyan
    // PISTA: o fillStyle está sendo definido DEPOIS do fillRect do corpo.
    // Em qual ordem o JavaScript executa essas linhas?
    // O que você precisa mover para que a cabeça apareça de cor diferente?
    ctx.fillRect(position.x, position.y, size, size)

    if (index === snake.length - 1) {
      ctx.fillStyle = "cyan"
    }
  })
}

const moveSnake = () => {
  const head = snake[snake.length - 1]

  if (!direction) return

  let newHead = { x: head.x, y: head.y }

  if (direction === "right") {
    newHead.x += size
  }
  if (direction === "left") {
    newHead.x -= size
  }
  if (direction === "down") {
    newHead.y += size
  }
  if (direction === "up") {
    newHead.y -= size
  }

  snake.push(newHead)

  // Se a cabeça comer a maçã
  if (newHead.x === food.x && newHead.y === food.y) {
    // Cria uma nova maçã em lugar aleatório
    food.x = randomPosition()
    food.y = randomPosition()

    // BUG 4 – PONTUAÇÃO AO COMER
    // Aqui a cobra comeu a maçã! A pontuação deveria aumentar.
    // PISTA: Qual operação matemática aumenta um valor em 1?
    // Não esqueça de atualizar o elemento HTML também (getElementById)!
    score - 1

    // Atualiza o recorde se necessário
    if (score > highScore) {
      highScore = score
      document.getElementById("highScore").innerText = highScore
    }

    // Não remove o último gomo (a cobra cresce)
  } else {
    // Remove o último gomo da cauda para dar o efeito de movimento normal
    snake.shift()
  }
}

// função para desenhar o grid do jogo, para ajudar a visualizar melhor
// o movimento da cobra e a posição da maçã, além de dar um toque mais retrô ao jogo
const drawGrid = () => {
  ctx.lineWidth = 1
  ctx.strokeStyle = "#191919"

  for (let x = 0; x < canvas.width; x += size) {
    ctx.beginPath()  // Inicia um novo caminho para cada linha,
                     // garantindo que as linhas sejam desenhadas corretamente sem se sobrepor
    ctx.moveTo(x, 0) // Move o ponto de início para a posição (x, 0),
                     // ou seja, o topo do canvas na coordenada x atual
    ctx.lineTo(x, canvas.height) // Desenha uma linha vertical da posição (x, 0)
                                 // até (x, canvas.height), ou seja, do topo até o fundo do
                                 // canvas na coordenada x atual
    ctx.stroke()     // Desenha a linha no canvas usando as configurações de estilo
                     // definidas (cor e largura da linha)
  }

  for (let y = 0; y < canvas.height; y += size) {
    ctx.beginPath()
    ctx.moveTo(0, y)
    ctx.lineTo(canvas.width, y)
    ctx.stroke()
  }
}

// --- REGRA DO GAME OVER ---
const checkCollision = () => {
  const head = snake[snake.length - 1]

  // BUG 5 – COLISÃO COM O PRÓPRIO CORPO
  // A cobra bate nas paredes, mas ainda não bate nela mesma!
  // PISTA: O array snake contém todos os gomos. Como você verificaria se
  // a cabeça (último elemento) tem as mesmas coordenadas x e y
  // que qualquer outro gomo anterior?
  // Dica: some(), forEach() ou um for loop podem ajudar aqui.

  // Se bater nas paredes do canvas (0 até 600)
  if (head.x < 0 || head.x >= canvas.width || head.y < 0 || head.y >= canvas.height) {
    gameOver()
  }
}

const gameOver = () => {
  direction = undefined // Para o movimento do canvas, já que a direção é indefinida,
                        // a cobra para de se mover, pois a mesma colidiu com a parede,
                        // ou seja, perdeu o jogo

  alert("Game Over! Tente novamente se tiver coragem....")

  // Reinicia a cobra para a posição inicial
  snake = [
    { x: 200, y: 200 },
    { x: 220, y: 200 },
    { x: 240, y: 200 }
  ]

  food.x = randomPosition() // Gera uma nova posição aleatória para a maçã, referente a coordenada x
  food.y = randomPosition() // Gera uma nova posição aleatória para a maçã, referente a coordenada y

  // BUG 6 – RESETAR PONTUAÇÃO
  // Quando o jogo reinicia, a pontuação deveria voltar para o início.
  // PISTA: Qual é o valor correto para a pontuação quando o jogo começa do zero?
  // Não esqueça de atualizar o elemento HTML (getElementById) depois de alterar a variável!
  score = 999
}

const gameLoop = () => {
  clearTimeout(loopId) // Se usa setTimeout, limpamos com clearTimeout

  ctx.clearRect(0, 0, canvas.width, canvas.height)
  drawGrid()       // Desenha o grid antes de desenhar a comida e a cobra,
                   // para que o grid fique atrás deles
  drawFood()       // Desenha a maçã
  drawSnake()      // Desenha a cobra
  moveSnake()      // Move a cobra, atualizando sua posição com base na direção atual
  checkCollision() // Verifica se perdeu

  loopId = setTimeout(() => {
    gameLoop()
  }, 50) // A cada 50ms, o jogo é atualizado, criando a ilusão de movimento
}

gameLoop()

// Capturando os movimentos do teclado corretamente (VULGO "DOR DE CABEÇA....")
document.addEventListener("keydown", (event) => {
  const key = event.key // Pegando a propriedade key do evento

  if (key === "ArrowRight" && direction !== "left") {
    direction = "right"
  }
  if (key === "ArrowLeft" && direction !== "right") {
    direction = "left"
  }
  if (key === "ArrowUp" && direction !== "down") {
    direction = "up"
  }
  if (key === "ArrowDown" && direction !== "up") {
    direction = "down"
  }
})

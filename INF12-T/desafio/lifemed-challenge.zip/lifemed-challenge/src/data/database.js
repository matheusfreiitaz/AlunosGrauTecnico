// Banco de dados simulado no localStorage
let usuariosCadastrados = JSON.parse(localStorage.getItem("usuariosCadastrados")) || [
  { email: "user@lifemed.com", senha: "123", nome: "LifeMed user" }
];

// PISTA: Como esse arquivo disponibiliza a variável para o resto do sistema?
